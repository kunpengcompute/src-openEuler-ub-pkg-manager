#!/bin/bash
source /usr/share/ub-pkg-manager/bin/00-ub-pkg-devm.sh

